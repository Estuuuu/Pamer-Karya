# file: modules/admin_view.py

import sqlite3
import os
import hashlib
from getpass import getpass

KODE_RAHASIA = '123'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def add_new_admin():

    clear_screen()
    print("--- Tambah Admin Baru ---")
    kode_input = getpass("Untuk keamanan, masukkan Kode Rahasia Akses: ")
    if kode_input != KODE_RAHASIA:
        print("\n[GAGAL] Kode Rahasia salah. Aksi dibatalkan.")
        return
   
    print("\nVerifikasi berhasil...")
    try:
        username = input("Masukkan username untuk admin baru: ").strip()
        password = getpass("Masukkan password: ")
        if not all([username, password]):
            print("\n[GAGAL] Username dan password tidak boleh kosong.")
            return
        conn = sqlite3.connect('portfolio.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Pengguna (username, password, role) VALUES (?, ?, ?)", (username, hashlib.sha256(password.encode()).hexdigest(), 'admin'))
        conn.commit()
        print(f"\n[SUKSES] Admin '{username}' berhasil dibuat!")
    except sqlite3.IntegrityError:
        print(f"\n[GAGAL] Username '{username}' sudah ada.")
    except Exception as e:
        print(f"\nTerjadi error: {e}")
    finally:
        if 'conn' in locals():
            conn.close()

def view_all_portfolios_admin():
   
    conn = sqlite3.connect('portfolio.db')
    cursor = conn.cursor()
    cursor.execute('''
    SELECT p.id_portofolio, p.judul, m.nama_mahasiswa, m.NIM
    FROM Portofolio p
    JOIN Mahasiswa m ON p.NIM = m.NIM
    ''')
    portfolios = cursor.fetchall()
    conn.close()
    if not portfolios:
        print("\nBelum ada portofolio.")
        return False
    print("\n--- DAFTAR SEMUA PORTOFOLIO ---")
    for p in portfolios: print(f"ID: {p[0]} | Judul: {p[1]} | Pemilik: {p[2]} ({p[3]})")
    return True

def get_full_portfolio_details(portfolio_id):
  
    conn = sqlite3.connect('portfolio.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT p.judul, p.deskripsi, m.nama_mahasiswa, m.NIM, m.prodi, m.tahun_angkatan
        FROM Portofolio p
        JOIN Mahasiswa m ON p.NIM = m.NIM
        WHERE p.id_portofolio = ?
    ''', (portfolio_id,))
    portfolio = cursor.fetchone()
    if not portfolio: print("Portofolio tidak ditemukan."); conn.close(); return
    print("\n--- DETAIL LENGKAP PORTOFOLIO ---")
    print(f"Judul: {portfolio[0]}\nDeskripsi: {portfolio[1]}\nPemilik: {portfolio[2]} (NIM: {portfolio[3]})\nProdi: {portfolio[4]} - Angkatan {portfolio[5]}")
    print("\n[ Pengalaman ]")
    cursor.execute("SELECT id_pengalaman, nama_kegiatan, peran, durasi FROM Pengalaman WHERE id_portofolio = ?", (portfolio_id,))
    pengalaman_list = cursor.fetchall()
    if pengalaman_list:
        for p in pengalaman_list: print(f"  ID: {p[0]} | {p[1]} sebagai {p[2]} ({p[3]})")
    else: print("  Tidak ada pengalaman.")
    print("\n[ Sertifikat ]")
    cursor.execute("SELECT id_sertifikat, nama_sertifikat, penerbit FROM Sertifikat WHERE id_portofolio = ?", (portfolio_id,))
    sertifikat_list = cursor.fetchall()
    if sertifikat_list:
        for s in sertifikat_list: print(f"  ID: {s[0]} | {s[1]}, oleh {s[2]}")
    else: print("  Tidak ada sertifikat.")
    conn.close()
    print("-" * 30)

def admin_menu(admin_data):
    while True:
        clear_screen()
        print(f"Selamat datang, Admin! (Login sebagai: {admin_data['username']})")
        print("\n--- MENU ADMIN (PENGAWAS) ---")
        print("1. Lihat Semua Portofolio Mahasiswa")
        print("2. Tambah Admin Baru")
        print("3. Logout")

        choice = input("Pilih menu: ")
        
        if choice == '1':
            view_all_portfolios_admin()
            try:
                p_id = input("\nMasukkan ID untuk lihat detail (atau Enter untuk kembali): ")
                if p_id: get_full_portfolio_details(int(p_id))
            except ValueError: print("Input ID tidak valid.")
        elif choice == '2':
            add_new_admin()
        elif choice == '3':
            print("Anda telah logout."); break
        else:
            print("Pilihan tidak valid.")
        
        input("\nTekan Enter untuk kembali ke menu...")